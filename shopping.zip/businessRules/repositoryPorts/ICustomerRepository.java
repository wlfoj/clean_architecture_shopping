package com.cart.shopping.businessRules.repositoryPorts;

import com.cart.shopping.businessRules.entities.Customer;

import java.util.List;
import java.util.Optional;

public interface ICustomerRepository {
    List<Customer> findAll();
    Optional<Customer> findById(long id);
    Customer save(Customer c);
    void deleteById(long id);
}
