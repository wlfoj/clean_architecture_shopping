package com.cart.shopping.businessRules.useCases;

import com.cart.shopping.businessRules.entities.Product;
import com.cart.shopping.businessRules.exceptions.NegativePrice;

import java.util.List;

public interface IProductService {
    public Product addProduct(Product p) throws NegativePrice;
    public List<Product> getAll();
    public Product getById(long id);
    public Product edit(long id, Product p) throws NegativePrice;
    public void deleteById(long id);
}
