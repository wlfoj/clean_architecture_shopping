package com.cart.shopping.businessRules.useCases;

import com.cart.shopping.businessRules.entities.Customer;
import com.cart.shopping.businessRules.exceptions.InvalidEmail;
import com.cart.shopping.businessRules.repositoryPorts.ICustomerRepository;

import java.util.List;
import java.util.Optional;

public class CustomerService implements ICustomerService{
    private final ICustomerRepository customerPort;

    public CustomerService(ICustomerRepository customerPort) {
        this.customerPort = customerPort;
    }

    @Override
    public Customer addCustomer(Customer c) throws InvalidEmail {
        //Validar email
        if(!c.isValidEmail()){
            throw new InvalidEmail();
        }
        return customerPort.save(c);
    }

    @Override
    public List<Customer> getAll() {
        return customerPort.findAll();
    }

    @Override
    public Customer getById(long id) {
        Optional<Customer> _customer = customerPort.findById(id);
        if(_customer.isPresent()){
            return _customer.get();
        }
        return null;
    }

    @Override
    public Customer edit(long id, Customer c) throws InvalidEmail{
        //Validar email
        if(!c.isValidEmail()){
            throw new InvalidEmail();
        }
        Customer editedCustomerEntity = null;
        // Verifica se existe alguém com o id
        Optional<Customer> _customer = customerPort.findById(id);
        // Se tiver preenche
        if (_customer.isPresent()) {
            editedCustomerEntity = _customer.get();
            editedCustomerEntity.setAddress(c.getAddress());
            editedCustomerEntity.setEmail(c.getEmail());
            editedCustomerEntity.setName(c.getName());
            editedCustomerEntity.setPhone(c.getPhone());
            editedCustomerEntity = customerPort.save(editedCustomerEntity);
        }
        return editedCustomerEntity;
    }

    @Override
    public void deleteById(long id) {
        customerPort.deleteById(id);
    }
}

