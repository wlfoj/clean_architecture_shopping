package com.cart.shopping.businessRules.useCases;

import com.cart.shopping.businessRules.entities.Customer;
import com.cart.shopping.businessRules.exceptions.InvalidEmail;

import java.util.List;

public interface ICustomerService {
    public Customer addCustomer(Customer c) throws InvalidEmail;
    public List<Customer> getAll();
    public Customer getById(long id);
    public Customer edit(long id, Customer c) throws InvalidEmail;
    public void deleteById(long id);
}
