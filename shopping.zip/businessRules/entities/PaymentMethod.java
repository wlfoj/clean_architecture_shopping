package com.cart.shopping.businessRules.entities;

/** Enumerador com os metodos de pagamento aceitados
 *
 */
public enum PaymentMethod {
    AVISTA, PIX, CREDITO, DEBITO;
}
