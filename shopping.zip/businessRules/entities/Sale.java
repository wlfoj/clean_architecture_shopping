package com.cart.shopping.businessRules.entities;

import java.time.LocalDateTime;
import java.util.List;

public class Sale {
    private long id;
    private LocalDateTime createdAt;
    private float price;
    private float discount;
    private PaymentMethod method;
    private Customer customer;
    private List<Item> cart;//Carrinho

    public Sale(){}

    public Sale(long id, LocalDateTime createdAt, float price, float discount,
                PaymentMethod method, Customer customer, List<Item> cart){
        this.id = id;
        this.createdAt = createdAt;
        this.price = price;
        this.discount = discount;
        this.method = method;
        this.customer = customer;
        this.cart = cart;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getDiscount() {
        return discount;
    }

    public void setDiscount(float discount) {
        this.discount = discount;
    }

    public PaymentMethod getMethod() {
        return method;
    }

    public void setMethod(PaymentMethod method) {
        this.method = method;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Item> getCart() {
        return cart;
    }

    public void setCart(List<Item> cart) {
        this.cart = cart;
    }

}
