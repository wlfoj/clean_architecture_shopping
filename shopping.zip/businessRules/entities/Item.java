package com.cart.shopping.businessRules.entities;

/** Classe que representa o item do carrinho
 * possui quantidade e o produto
 *
 */
public class Item {
    private Product product;
    private int qtd;

    public Item(){}

    public Item(Product product, int qtd){
        this.product = product;
        this.qtd = qtd;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

}