package com.cart.shopping.businessRules.exceptions;

public class NegativePrice extends Exception {

    private static final long serialVersionUID = 1L;

    public NegativePrice() {
        super("Preco informado negativo, insira um valor maior que 0");
    }
}
