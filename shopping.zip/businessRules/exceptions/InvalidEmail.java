package com.cart.shopping.businessRules.exceptions;

public class InvalidEmail extends Exception{
    private static final long serialVersionUID = 1L;

    public InvalidEmail() {
        super("Formato de email inválido");
    }
}
