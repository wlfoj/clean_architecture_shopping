package com.cart.shopping.frameworks.databaseJPA;

import com.cart.shopping.businessRules.entities.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//@Repository
public interface CustomerRepositoryJPA extends JpaRepository<Customer, Long> {
}
