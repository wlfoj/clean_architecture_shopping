package com.cart.shopping.frameworks.repositoriesImp;

import com.cart.shopping.businessRules.entities.Product;
import com.cart.shopping.businessRules.repositoryPorts.IProductRepository;
import com.cart.shopping.frameworks.databaseJPA.ProductRepositoryJPA;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class ProductRepositoryImp implements IProductRepository {
    private final ProductRepositoryJPA productRepositoryJPA;

    public ProductRepositoryImp(ProductRepositoryJPA productRepositoryJPA) {
        this.productRepositoryJPA = productRepositoryJPA;
    }

    @Override
    public List<Product> findAll() {
        return this.productRepositoryJPA.findAll();
    }

    @Override
    public Optional<Product> findById(long id) {
        return this.productRepositoryJPA.findById(id);
    }

    @Override
    public Product save(Product c) {
        return this.productRepositoryJPA.save(c);
    }

    @Override
    public void deleteById(long id) {
        this.productRepositoryJPA.deleteById(id);
    }
}
