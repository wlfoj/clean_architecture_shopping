package com.cart.shopping.frameworks.repositoriesImp;

import com.cart.shopping.businessRules.entities.Customer;
import com.cart.shopping.businessRules.repositoryPorts.ICustomerRepository;
import com.cart.shopping.frameworks.databaseJPA.CustomerRepositoryJPA;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

//@Component
public class CustomerRepositoryImp implements ICustomerRepository {
    private final CustomerRepositoryJPA customerRepositoryJPA;

    public CustomerRepositoryImp(CustomerRepositoryJPA customerRepositoryJPA) {
        this.customerRepositoryJPA = customerRepositoryJPA;
    }

    @Override
    public List<Customer> findAll() {
        return this.customerRepositoryJPA.findAll();
    }

    @Override
    public Optional<Customer> findById(long id) {
        return this.customerRepositoryJPA.findById(id);
    }

    @Override
    public Customer save(Customer c) {
        return  this.customerRepositoryJPA.save(c);
    }

    @Override
    public void deleteById(long id) {
        this.customerRepositoryJPA.deleteById(id);
    }
}
