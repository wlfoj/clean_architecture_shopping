package com.cart.shopping.adapters.dtos.response;

public class ProductResDto {
    public long id;
    public String name;
    public float price;
}
