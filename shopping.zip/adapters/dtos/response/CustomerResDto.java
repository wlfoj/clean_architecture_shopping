package com.cart.shopping.adapters.dtos.response;

public class CustomerResDto {
    public long id;
    public String name;
    public String email;
}
