package com.cart.shopping.adapters.dtos.request;

public class ProductReqDto {
    public String name;
    public float price;
}
