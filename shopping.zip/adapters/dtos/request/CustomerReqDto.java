package com.cart.shopping.adapters.dtos.request;

public class CustomerReqDto {
    public String name;
    public String email;
    public String address;
    public String phone;
}
